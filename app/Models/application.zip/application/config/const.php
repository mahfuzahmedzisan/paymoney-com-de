<?php defined('SYSPATH') OR die('No direct access allowed.');

$config['setting'] = array
(
	'banking' => array
	(
		'type' => array
		(
			'game' => 'Игра',
			'profit' => 'Прибыль',
			'jackpot' => 'Джекпот',
		)
	)
);