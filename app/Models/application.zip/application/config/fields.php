<?php defined('SYSPATH') OR die('No direct access allowed.');

$config = array
(
	'test1' => 'test1',
);