<?php defined('SYSPATH') OR die('No direct access allowed.'); 

$config = array
(
	'top' => 'common/top',
	'left' => 'common/left',	
	'meta' => 'common/meta',
	'list' => 'common/list',
	'form' => 'common/form',
	'logo' => 'common/logo',
	'foot' => 'common/foot',
	'quick' => 'common/quick',
	'atack' => 'common/atack',
	'layer' => 'common/layer',
	'panel' => 'common/panel',
	'switch' => 'common/switch',
	'logout' => 'common/logout',
	'header' => 'common/header',
	'footer' => 'common/footer',
	'profile' => 'common/profile',
	'breadcrumps' => 'common/breadcrumps',	
);		