<?php defined('SYSPATH') OR die('No direct access allowed.');

$config['login'] = '/login';
$config['logout'] = '/logout';

$config['main'] = '/finance/cashin';