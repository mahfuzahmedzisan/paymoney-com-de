<?php defined('SYSPATH') or die('No direct access allowed.');

$config = array
(
	'model' => array
	(
		'fields' => array
		(
			'items_per_page' => 10,
		),
	),
);