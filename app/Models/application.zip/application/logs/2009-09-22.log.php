<?php defined('SYSPATH') or die('No direct script access.'); ?>

2009-09-22 18:01:30 +04:00 --- error: Uncaught Kohana_Exception: The requested view, common/meta, could not be found in file Z:/home/adminka/www/system/core/Kohana.php on line 1162
