<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php echo $meta; ?>
<?php echo $header; ?>
logout
<?php echo $footer; ?>