<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<?php /*

<div class="control">Под контролем</div>
<div class="warning">Атака на сервер</div>

*/ ?>