<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<?php /*

<div class="where"> 
	<a href="javascript:;" title="#">Overview</a> > <a href="javascript:;" title="#">Campus</a> > <a href="javascript:;" title="#">Payments</a> 
</div>

*/ ?>