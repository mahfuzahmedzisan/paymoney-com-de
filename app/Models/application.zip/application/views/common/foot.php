<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<div class="footer"> Copyright &copy; 2007-<?php echo date("Y"); ?> <a href="http://www.casino4you.org/" target="_blank">Казино для Вас</a>. Все права защищены. </div>