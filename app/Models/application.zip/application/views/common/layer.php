<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<div class="layer">
    <!--[if lte IE 6.5]><iframe></iframe><![endif]-->
</div>