<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div class="logo"></div>