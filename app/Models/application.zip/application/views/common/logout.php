<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<a href="/logout" title="" class="exit">Выход</a>