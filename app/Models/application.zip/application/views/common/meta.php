<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Панель управления</title>
<link href="/media/style/style.css" rel="stylesheet" type="text/css" />
<!--[if IE 6]><link rel="stylesheet" href="/media/style/ie6.css" type="text/css" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="/media/style/ie7.css" type="text/css" /><![endif]-->
<script language="javascript" type="text/javascript" src="/media/js/jquery.js"></script>
</head>