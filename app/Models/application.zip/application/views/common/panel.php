﻿<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<div class="title">Игровой комплекс</div>

<div class="license"><font>Номер лицензии —</font> OPJKNT ESADQ8 CA8880</div> 

<div class="select"> Аккаунты —
    <select class="f13">
        <option>ALEX CASINO</option>
    </select>
</div>

<?php /*

<div class="select1"> Переход в —
    <select class="f13">
        <option>Клуб 1</option>
    </select>
</div>

*/ ?>