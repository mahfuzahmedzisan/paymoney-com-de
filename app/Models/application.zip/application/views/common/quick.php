<?php defined('SYSPATH') or die('No direct access allowed.'); /* ?>

<div class="block-left"> Онлайн монитор <br />
    <select class="f11">
        <option>Выбрать что-то</option>
    </select>
</div>
 
<div class="block-right">
    <table cellpadding="0" cellspacing="0" class="t1">
        <tr>
            <td><table cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type2" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type3" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                </table></td>
            <td><table cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type2" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type3" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                    <tr>
                        <td class="w03">сумма игр</td>
                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                    </tr>
                </table></td>
        </tr>
    </table>
</div>
<br class="clearfloat" />

*/ ?>