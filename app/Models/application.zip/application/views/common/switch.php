<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<div class="block2"> 
	<a href="/online/monitor" title="Онлайн монитор"><img src="/media/images/button11.png" alt="#" /></a><span>Показывает работу игрового комплекса в режиме реального времени</span> <a href="/online/monitor" title="Онлайн монитор">Показать монитор &rarr;</a> 
</div>