<?php defined('SYSPATH') or die('No direct access allowed.'); ?>

<ul class="menu2">
    <li class="q16"><a href="javascript:;" title="Profile" name="get_profile"><?php echo Auth::instance()->get_user()->username; ?></a></li>
    <!--
    <li class="q17"><a href="javascript:;" title="#">Сообщения (25)</a></li>
    -->
    <!-- 
    <li class="q18"><a href="javascript:;" title="#">Профиль</a></li>
    -->
    <!-- 
    <li class="q19"><a href="javascript:;" title="#">Помощь</a></li>
    -->
</ul>