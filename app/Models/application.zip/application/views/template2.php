<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<?php echo $template->meta; ?>
<?php echo $template->header; ?>

<div class="layer">
    <!--[if lte IE 6.5]><iframe></iframe><![endif]-->
</div>
<div class="profile">
    <div class="tabs">
        <ul>
            <li class="active last">Главное</li>
        </ul>
        <br class="clearfloat" />
    </div>
    <br class="clearfloat" />
    <div class="bg">
        <div class="in-bg">
            <table cellpadding="0" cellspacing="0" class="t1">
                <tr valign="top">
                    <td class="w02"><p> Название <br />
                            <input type="text" class="f03" />
                        </p>
                        <p> Описание <br />
                            <textarea class="f04"></textarea>
                        </p>
                        <table cellpadding="0" cellspacing="0" class="t2">
                            <tr valign="top">
                                <td><p> Юридический адрес <br />
                                        <textarea class="f09"></textarea>
                                    </p></td>
                                <td><p> Юридический адрес <br />
                                        <textarea class="f09"></textarea>
                                    </p></td>
                            </tr>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="t3">
                            <tr>
                                <td><p> Главный администратор <br />
                                        <input type="text" class="f05" />
                                    </p></td>
                                <td><p> Доступ <br />
                                        <select class="f01">
                                            <option>Полный</option>
                                        </select>
                                    </p></td>
                            </tr>
                        </table></td>
                </tr>
            </table>
            <div class="button2"> <a href="#" title="#"><img src="/media/images/button7.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button12.png" alt="#" /></a> </div>
        </div>
    </div>
</div>
<div class="center">
    <div class="head">
        <div class="logo"></div>
        <ul class="menu2">
            <li class="q16"><a href="#" title="#">Admin</a></li>
            <li class="q17"><a href="#" title="#">Сообщения (25)</a></li>
            <li class="q18"><a href="#" title="#">Профиль</a></li>
            <li class="q19"><a href="#" title="#">Помощь</a></li>
        </ul>
        <a href="#" title="#" class="exit">Выход</a>
        <div class="control">Под контролем</div>
        <div class="warning">Атака на сервер</div>
    </div>
    <div class="block">
        <div class="block-l">
            <div class="block-r">
                <div class="smalllogo"></div>
                <div class="select"> Аккаунты —
                    <select class="f13">
                        <option>Игровой клуб</option>
                    </select>
                </div>
                <div class="select1"> Переход в —
                    <select class="f13">
                        <option>Клуб 1</option>
                    </select>
                </div>
                <div class="block-left"> Онлайн монитор <br />
                    <select class="f11">
                        <option>Выбрать что-то</option>
                    </select>
                </div>
                 
                <div class="block-right">
                    <table cellpadding="0" cellspacing="0" class="t1">
                        <tr>
                            <td><table cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type2" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type3" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                </table></td>
                            <td><table cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type2" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type3" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                    <tr>
                                        <td class="w03">сумма игр</td>
                                        <td><span class="type1" style="width: 200px;"><span><span>&nbsp;</span></span></span>75$</td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table>
                </div>
                <br class="clearfloat" />
            </div>
        </div>
    </div>
    <div class="block2"> <a href="#" title="#"><img src="/media/images/button11.png" alt="#" /></a><span>Показывает что-то там в режиме реальнг времени</span><a href="#" title="#">Показать монитор &rarr;</a> </div>
    <div class="wrapper">
        <div class="wrapper-t">
            <div class="wrapper-b-l">
                <div class="wrapper-b-r">
                    <div class="container">
                        <div class="content">
                            <div class="main">
                                <div class="where"> <a href="#" title="#">Overview</a> > <a href="#" title="#">Campus</a> > <a href="#" title="#">Payments</a> </div>
                                <div class="desc">
                                    <h2>Новое казино</h2>
                                    <p> Each pool of clusters is optimized for a specific task (web services, email, databases and more). With multiple servers handling each task, redundancy is built-in and your sites never have to fight for the resources of a single server. </p>
                                </div>
                                <div class="pad">
                                    <div class="button">
                                        <div class="button-r"> <a href="#" title="#"><img src="/media/images/button1.png" alt="#" /></a> </div>
                                    </div>
                                    <div class="button">
                                        <div class="button-r"> <a href="#" title="#"><img src="/media/images/button2.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button3.png" alt="#" /></a> </div>
                                    </div>
                                    <br class="clearfloat" />
                                </div>
                                <h2>Добавить новый аккаунт</h2>
                                <div class="tabs">
                                    <ul>
                                        <li class="active">Главное</li>
                                        <li><a href="#" title="#">Дополнительно</a></li>
                                        <li class="last"><a href="#" title="#">Настройки</a></li>
                                    </ul>
                                    <br class="clearfloat" />
                                </div>
                                <br class="clearfloat" />
                                <div class="bg">
                                    <div class="in-bg">
                                        <table cellpadding="0" cellspacing="0" class="t1">
                                            <tr valign="top">
                                                <td class="w02"><p> Название <br />
                                                        <input type="text" class="f03" />
                                                        <span class="up-box">Разрешено</span> </p>
                                                    <p> Описание <br />
                                                        <textarea class="f04"></textarea>
                                                    </p>
                                                    <table cellpadding="0" cellspacing="0" class="t2">
                                                        <tr valign="top">
                                                            <td><p> Юридический адрес <br />
                                                                    <textarea class="f09"></textarea>
                                                                </p></td>
                                                            <td><p> Юридический адрес <br />
                                                                    <textarea class="f09"></textarea>
                                                                </p></td>
                                                        </tr>
                                                    </table>
                                                    <table cellpadding="0" cellspacing="0" class="t3">
                                                        <tr>
                                                            <td><p> Главный администратор <br />
                                                                    <input type="text" class="f05" />
                                                                    <span class="up-box2">Неправильный формат</span> </p>
                                                                <p> Номер телефона <br />
                                                                    <input type="text" class="f06" />
                                                                    <span class="up-box3">Обязательное поле</span> </p>
                                                                <p> Паспортные данные <br />
                                                                    Серия
                                                                    <input type="text" class="f07 green" />
                                                                    Номер
                                                                    <input type="text" class="f08 red" />
                                                                </p>
                                                                <p> Юридический адрес <br />
                                                                    <textarea class="f09"></textarea>
                                                                </p></td>
                                                            <td><p> Доступ <br />
                                                                    <select class="f01">
                                                                        <option>Полный</option>
                                                                    </select>
                                                                </p>
                                                                <div class="ava"> <strong>Аватар администратора</strong> <br />
                                                                    <img src="thumbs/ava.jpg" alt="#" />
                                                                    <p> <a href="#" title="#"><img src="/media/images/button9.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button10.png" alt="#" /></a> </p>
                                                                </div></td>
                                                        </tr>
                                                    </table></td>
                                                <td class="w01"><p> Страна <br />
                                                        <select class="f01">
                                                            <option>Россия</option>
                                                        </select>
                                                    </p>
                                                    <p> Город <br />
                                                        <select class="f02">
                                                            <option>Саратов</option>
                                                        </select>
                                                    </p>
                                                    <p> Статус <br />
                                                        <select class="f02">
                                                            <option>Активен</option>
                                                        </select>
                                                    </p></td>
                                            </tr>
                                        </table>
                                        <div class="button2"> <a href="#" title="#"><img src="/media/images/button4.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button5.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button6.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button7.png" alt="#" /></a><a href="#" title="#"><img src="/media/images/button8.png" alt="#" /></a> </div>
                                    </div>
                                </div>
                                <h2>Управление списками</h2>
                                <div class="tabs2">
                                    <ul>
                                        <li class="active">Главное</li>
                                        <li><a href="#" title="#">Дополнительно</a></li>
                                        <li class="last"><a href="#" title="#">Настройки</a></li>
                                    </ul>
                                    <br class="clearfloat" />
                                </div>
                                <br class="clearfloat" />
                                <div class="bg2">
                                    <div class="in-bg2">
                                        <table cellpadding="0" cellspacing="0" class="t4">
                                            <tr>
                                                <td width="29"></td>
                                                <td>Название <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="132">Статус <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="111">Контакты <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="108">Настройки <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="85">Клубы <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="82">Игроки <img src="/media/images/bullet.gif" alt="#" /></td>
                                                <td width="24"></td>
                                            </tr>
                                        </table>
                                        <table cellpadding="0" cellspacing="0" class="t5">
                                            <tr>
                                                <td width="29"></td>
                                                <td><input type="text" class="f10" /></td>
                                                <td width="132"><select class="f11">
                                                        <option>Активен</option>
                                                    </select></td>
                                                <td width="410"></td>
                                            </tr>
                                        </table>
                                        <div class="pad2">
                                            <table cellpadding="0" cellspacing="0" class="t6">
                                                <tr class="active">
                                                    <td width="29">&nbsp;&nbsp;
                                                        <input type="checkbox" /></td>
                                                    <td><strong><a href="#" title="#">Аккаунт 1</a></strong></td>
                                                    <td width="132"><img src="/media/images/flag1.gif" alt="#" /> Не активен</td>
                                                    <td width="111">Не активен</td>
                                                    <td width="108"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="85"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="82"><a href="#" title="#">edit</a></td>
                                                    <td width="24"><a href="#" title="#"><img src="/media/images/bullet3.gif" alt="#" /></a></td>
                                                </tr>
                                                <tr>
                                                    <td width="29">&nbsp;&nbsp;
                                                        <input type="checkbox" /></td>
                                                    <td><strong><a href="#" title="#">Аккаунт 1</a></strong></td>
                                                    <td width="132"><img src="/media/images/flag1.gif" alt="#" /> Не активен</td>
                                                    <td width="111">Не активен</td>
                                                    <td width="108"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="85"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="82"><a href="#" title="#">edit</a></td>
                                                    <td width="24"><a href="#" title="#"><img src="/media/images/bullet3.gif" alt="#" /></a></td>
                                                </tr>
                                                <tr>
                                                    <td width="29">&nbsp;&nbsp;
                                                        <input type="checkbox" /></td>
                                                    <td><strong><a href="#" title="#">Аккаунт 1</a></strong></td>
                                                    <td width="132"><img src="/media/images/flag1.gif" alt="#" /> Не активен</td>
                                                    <td width="111">Не активен</td>
                                                    <td width="108"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="85"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="82"><a href="#" title="#">edit</a></td>
                                                    <td width="24"><a href="#" title="#"><img src="/media/images/bullet3.gif" alt="#" /></a></td>
                                                </tr>
                                                <tr class="last">
                                                    <td width="29">&nbsp;&nbsp;
                                                        <input type="checkbox" /></td>
                                                    <td><strong><a href="#" title="#">Аккаунт 1</a></strong></td>
                                                    <td width="132"><img src="/media/images/flag1.gif" alt="#" /> Не активен</td>
                                                    <td width="111">Не активен</td>
                                                    <td width="108"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="85"><a href="#" title="#"><img src="/media/images/bullet2.gif" alt="#" /></a></td>
                                                    <td width="82"><a href="#" title="#">edit</a></td>
                                                    <td width="24"><a href="#" title="#"><img src="/media/images/bullet3.gif" alt="#" /></a></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="filter-l"> Отмеченные &nbsp;
                                            <select class="f02">
                                                <option>Удалить</option>
                                            </select>
                                        </div>
                                        <div class="filter-r"> Показывать &nbsp;
                                            <select class="f12">
                                                <option>10</option>
                                            </select>
                                        </div>
                                        <div class="pages">Страницы &nbsp;&nbsp;<span>1</span><a href="#" title="#">2</a><a href="#" title="#">3</a><a href="#" title="#">4</a><a href="#" title="#">5</a></div>
                                        <br class="clearfloat" />
                                    </div>
                                </div>
                                <div class="info">
                                    <ul>
                                        <li><span>*</span>Определены соперники украинских клубов в плей-офф Лиги Европы<br class="clearfloat" />
                                        </li>
                                        <li><span>**</span>Израиль получил запрос от Украины о возможном пребывании Лозинского<br class="clearfloat" />
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="left">
                            <div class="menu">
                                <ul>
                                    <li><span class="q01"><a href="#" title="#">Главная</a></span></li>
                                    <li><span class="q02"><a href="#" title="#">Онлайн монитор</a></span></li>
                                </ul>
                                <h3>Финансы</h3>
                                <ul>
                                    <li><span class="q03"><a href="#" title="#">Пинкоды</a></span></li>
                                    <li><span class="q04"><a href="#" title="#">Пополнение средств</a></span></li>
                                    <li><span class="q05"><a href="#" title="#">Заказы на выплату</a></span></li>
                                </ul>
                                <h3>Управление</h3>
                                <ul>
                                    <li><span class="q06"><a href="#" title="#">Клубы и игры</a></span></li>
                                    <li><span class="q07"><a href="#" title="#">Управление игроками</a></span></li>
                                </ul>
                                <h3>Общение</h3>
                                <ul>
                                    <li class="active"><span class="q08"><a href="#" title="#">Контакты и филиалы</a></span></li>
                                </ul>
                                <h3>Пользователи</h3>
                                <ul>
                                    <li><span class="q09"><a href="#" title="#">Группы пользователей</a></span></li>
                                    <li><span class="q10"><a href="#" title="#">Пользователи</a></span></li>
                                    <li><span class="q10"><a href="#" title="#">Игроки</a></span></li>
                                </ul>
                                <h3>Настройки</h3>
                                <ul>
                                    <li><span class="q11"><a href="#" title="#">Типы игроков</a></span></li>
                                    <li><span class="q12"><a href="#" title="#">Игровые банки</a></span></li>
                                    <li><span class="q13"><a href="#" title="#">Шаблоны профилей</a></span></li>
                                    <li><span class="q14"><a href="#" title="#">Значения</a></span></li>
                                    <li><span class="q15"><a href="#" title="#">Рассылка отчетов</a></span></li>
                                </ul>
                            </div>
                            <div class="about">
                                <div class="about-t">
                                    <ul>
                                        <li><a href="#" title="#">Общие вопросы</a></li>
                                        <li><a href="#" title="#">Связаться с администрацией</a> <sup>Бета</sup></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <br class="clearfloat" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer"> Copyright &copy; 2008 Casino Royal. All rights reserved. Дизайн сайта — 73dpi </div>
</div>

<?php echo $footer; ?>