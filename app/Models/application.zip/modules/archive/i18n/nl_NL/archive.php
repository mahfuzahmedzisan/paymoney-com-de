<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'De directory die je opgaf om het bestand in op te slaan, %s, is niet schrijfbaar. Stel de correcte permissies in en probeer opnieuw.',
	'filename_conflict'    => 'De bestandsnaam die je opgaf voor het archief, %s, bestaat al en is niet schrijfbaar. Verwijder dat bestand en probeer opnieuw.',
);