<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_marker'		=>	'Invalid marker params (latitude: %s, longitude: %s)',
	'invalid_dimensions'	=>	'Invalid map dimensions (width: %s, height: %s)',
);