<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_marker'	=>	'Некорректные координаты маркера (широта: %s, долгота: %s)',
	'invalid_dimensions'	=>	'Некорректные размеры карты (ширина: %s, высота: %s)',
);