<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'                 => 'Einige benötigte Felder wurden nicht übergeben: %s',
	'gateway_connection_error' => 'Fehler bei der Verbindung zum Bezahldienst aufgetreten. Sollte der Fehler weiterhin bestehen, kontaktieren Sie bitte den Webmaster.',
	'invalid_certificate'      => 'Das Zertifikat ist ungültig: %s',
	'no_dlib'                  => 'Konnte die dynamische Bibliothek nicht laden: %s',
	'error'                    => 'Fehler bei Transaktion aufgetreten: %s',
);