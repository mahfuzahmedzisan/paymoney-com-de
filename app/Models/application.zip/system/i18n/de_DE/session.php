<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'Der Sessionname %s ist ungültig. Dieser darf nur aus alphanumerischen Zeichen und mindestens einem Buchstaben bestehen.',
);