<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'The %s group is not defined in your pagination configuration.',
	'page'     => 'page',
	'pages'    => 'pages',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'of',
	'first'    => 'first',
	'last'     => 'last',
	'previous' => 'previous',
	'next'     => 'next',
);
