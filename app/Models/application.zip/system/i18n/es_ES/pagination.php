<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'El grupo %s no esta definido en la configuracion de la paginacion.', 
	'page'     => 'página',
	'pages'    => 'páginas',
	'item'     => 'elemento',
	'items'    => 'elementos',
	'of'       => 'de',
	'first'    => 'primero',
	'last'     => 'último',
	'previous' => 'anterior',
	'next'     => 'siguiente',
);
