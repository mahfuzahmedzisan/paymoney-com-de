<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Les méthodes de requête ne peuvent pas être utilisées avec l\'ORM';