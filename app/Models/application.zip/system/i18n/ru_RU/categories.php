<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'header' => 'Управление категориями игр',
	'description' => 'В этом модуле вы можите управлять категориями игр',
	'list' => 'Список категорий', 
    'title' => 'Название',
	'count' => 'Количество игр',
	'sort' => 'Сорт.',
	'edit' => 'Редактирование категории',
	'main' => 'Главное',
	'title_description' => 'Название категории',
	'sort_description' => 'Сортировка, цифра,<br />по возрастанию',
);
