<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'slots_machine' => 'Слот автоматы',
	'table_games' => 'Настольные игры',
	'other_games' => 'Другие игры',
);