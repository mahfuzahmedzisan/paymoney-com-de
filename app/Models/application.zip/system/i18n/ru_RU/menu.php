<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'header' => array
	(
		'cash' => 'Касса',
		'rules' => 'Правила',
		'help' => 'Помощь',
	),
	
	'footer' => array
	(
		'terms' => 'Информация к использованию',
		'license' => 'Лицензионное соглашение',
	),	
);