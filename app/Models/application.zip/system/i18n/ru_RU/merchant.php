<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'form' => array
    (
        'header' => 'Редактирование мерчанта',
    	'name' => 'Название',
    	'name_description' => 'Название мерчанта',
    	'form' => 'Форма',
    	'form_description' => 'Форма мерчанта',
    	'secret_key' => 'Секретный ключ',
    	'secret_key_description' => 'Секретный ключ',
    ),
    
    'main' => array
    (
    	'header' => 'Управление мерчантами',
    	'description' => 'В этом модуле вы можете управлять мерчантами',
    	'list' => 'Список мерчантов',
    	'name' => 'Название',
    	'form' => 'Форма',
    	'secret_key' => 'Секретный ключ',
    )
);