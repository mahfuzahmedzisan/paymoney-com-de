<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'header' => 'Управление музыкой',
	'description' => 'В этом модуле вы сможете редактировать добавлять и удалять музыкальные треки.',
	'list' => 'Список треков',
	'artist' => 'Исполнитель',
	'track' => 'Название трека',
	'file' => 'Файл',
	'edit' => 'Редактирование трека',
	'track_description' => 'Название композиции',
	'artist_description' => 'Исполнитель композиции',
	'file_description' => 'Загрузить mp3 файл',
);