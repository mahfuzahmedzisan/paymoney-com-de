<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'auth' => array
	(
		'failed' => 'Ошибка',
	),	
	'forgot' => array
	(
		'successfully' => 'Отправлено',
		'failed' => 'Ошибка',
		'notfound' => 'Не найдено',
	),
);