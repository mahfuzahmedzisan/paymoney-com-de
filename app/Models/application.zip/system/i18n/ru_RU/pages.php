<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'header' => 'Управление страницами',
	'description' => 'В этом модуле вы можите управлять информационными страницами',
	'list' => 'Список страниц', 
    'title' => 'Название',
	'body_ru' => 'Русский',
	'body_en' => 'Английиский',
	'edit' => 'Редактирование категории',
	'main' => 'Главное',
	'title_description' => 'Название страницы',
	'body_ru_description' => 'Текст страницы на русском языке',
	'body_en_description' => 'Текст страницы на английском языке',

);
