<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'successfully' => 'Добавлен',
    'absent' => 'Отсутствует',
    'empty' => 'Пусто',
);