<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'main' => 'Главное',
    'name' => 'Имя',
    'username' => 'Логин',
	'email' => 'Email',
	'phone' => 'Телефон',
	'sex' => 'Пол',
    'password' => 'Пароль',
	'old_password' => 'Старый пароль',
	'new_password' => 'Новый пароль',
	'confirm_new_password' => 'Подтверждение нового пароля',
	'save_success' => 'Данные успешно сохранены',
	'password_save_success' => 'Пароль успешно изменен',
);