<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'url' => 'URL сайта',
    'title' => 'Название "META Title"',
	'description' => 'Описание "META Description"',
	'keywords' => 'Ключевые слова "META Keywords"',
	'google_analytics' => 'Google Analytics',
	'google_webmaster_tools' => 'Google Webmaster Tools',
	'one_login' => 'Возможность авторизации под одним логином',
	'currency' => 'Курс покупки валюты',
	'demo_user_balance' => 'Баланс при входе в демо режиме',
	'lang_id_default' => 'Язык сайта по умолчанию',
	'banking_limit_min_cash' => 'Минимальный баланс банка игры',
	'banking_limit_min_cash_bonus' => 'Минимальный баланс банка бонуса',
);
