<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Отправка письма не удалась.'
);
