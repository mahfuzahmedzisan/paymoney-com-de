INSERT INTO `metas` (`url`, `title`, `description`, `keywords`) VALUES ('privacy-policy', 'Privacy Policy', 'Privacy Policy', '');

INSERT INTO `metas` (`url`, `title`, `description`, `keywords`) VALUES ('deposit/confirm', 'Deposit confirm', 'Deposit confirm', '');